﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using GXPEngine;

namespace GXPEngine
{
    public class UserInterface : EasyDraw
    { 
        static int screenX = 1280;
        static int screenY = 720;
        int offsetX = 720 / 2;
        int offsetY = 720 / 2;
        string spriteHearts = "reference to heart here";
        public int waveHeight = 1;

        private Level _level;

        public UserInterface() : base(screenX, screenY)
        {
           
        }	

        void Text()
        {
            // Text
            
            graphics.Clear(Color.Empty);

            Fill(Color.White);
            TextSize(30f);
            TextAlign(CenterMode.Center, CenterMode.Center);
            TextFont("Verdana", 30f, FontStyle.Bold);

            Text("SCORE:", 1140, 150); // Text score letters
            Text("00000", 1140, 200); // Text score numbers
            Text("WAVE: " + _level.getWave(), 140, 300); // Wave number

            // Hearts
            Fill(Color.Red);
            Rect(90, 150, 50, 50);
            Text("x 3", 170, 150);

            // Circles
            for (int i = 0; i < 7; i++)
            {
                if (i == 0 || i == 3 || i == 6)
                {
                    Fill(Color.LawnGreen);
                    Ellipse(140, 390 + (i * 40), 50, 50);
                }
                else
                {
                    Fill(Color.Beige);
                    Ellipse(140, 390 + (i * 40), 15, 15);
                }
            }
        }
        public void WeaponAttack(float playerX, float playerY, bool isCharged)
        {
            if (isCharged)
            {
                Fill(Color.Blue);
                Ellipse(playerX, playerY, 100, 100);
            }
            else
            {
                Fill(Color.Red);
                Ellipse(playerX, playerY, 100, 100);
            }
            
        }

        void Update()
        {
             if (_level == null)
             {
                 _level = parent.FindObjectOfType<Level>();
             }
            
            Text();
        }
	}
}
