﻿using System;
using GXPEngine;


public class Grass : Sprite
{
    public Grass() : base("Overgrown_Grass.png")
    {

    }
} //case 0

