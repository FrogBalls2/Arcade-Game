﻿using System;
using GXPEngine;

public class Enemy : AnimationSprite
{
    float speedX;
    float speedY;
    int health;
    float animationSpeed = 0.05f;
    
    public Enemy() : base("VenusFlytrap.png", 7, 1)
    {
        SetOrigin(width/2,height/2);
        speedX = 1.0f;
        speedY = 1.0f;
         health = 1;  
    }

    public void EnemyGone()
    {
        this.LateDestroy();
    }
    void Update()
    {
        EnemyAnimator();
        FindPlayer();
    }

    void EnemyAnimator()
    {
        SetCycle(0, 7);
        Animate(animationSpeed);
    }


    void FindPlayer()
    {
        x = x + speedX;
        y = y + speedY;
        speedX = speedX * 0.9f;
        speedY = speedY * 0.9f;
    }
}