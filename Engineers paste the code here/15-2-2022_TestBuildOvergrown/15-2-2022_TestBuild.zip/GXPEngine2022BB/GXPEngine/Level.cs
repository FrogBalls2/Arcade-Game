﻿using GXPEngine;
using System.Collections.Generic;
using System;

public class Level : GameObject
{
    UserInterface ui;

    List<Grass> grassTiles;

    //timer
    float spawnTime;
    float delay = 2;
    float currentTime;
    float delayDecrease = 0.05f; // each wave the delay of the enemy spawn decreases
    bool nextWaveActivate = false;
    

    int nextWave_ = 1;

    Random rnd = new Random();
    
    const int WIDTH = 23;
    const int HEIGHT = 40;
    const int SIZE = 32;

    void Timer()
    {
        currentTime = Time.time / 1000;
        
        if (currentTime >= spawnTime)
        {
            int randomNumber = rnd.Next(0, grassTiles.Count);
            Grass selectedTile = grassTiles[randomNumber];
            Enemy enemy = new Enemy();
            enemy.x = selectedTile.x;
            enemy.y = selectedTile.y;
            AddChild(enemy);

            spawnTime = currentTime + delay;
        }
    }


    int[,] level = new int[WIDTH, HEIGHT]
    {
     {0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,4,4,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,4,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,4,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,4,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,4,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,4,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,4,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,4,4,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0 },

    };

    public Level()
    {
        ui = FindObjectOfType<UserInterface>();
        grassTiles = new List<Grass>();
        // Player player = new Player();
        //AddChild(player);
        //HUD hud = new HUD(player);
        // AddChild(hud);

        for (int row = 0; row < WIDTH; row++)
        {
            for (int col = 0; col < HEIGHT; col++)
            {
                int tile = level[row, col];
                createTile(row, col, tile);
            }
        }
    }

    void createTile(int row, int col, int tile)
    {
        switch (tile)
        {
            case 1:
                Tree tree = new Tree();
                AddChild(tree);
                tree.x = col * SIZE;
                tree.y = row * SIZE;
                break;

            case 2:
                Grass grass = new Grass();
                AddChild(grass);
                grass.x = col * SIZE;
                grass.y = row * SIZE;
                break;

            case 3:
               Enemy enemy = new Enemy();
               AddChild(enemy);
               enemy.x = col * SIZE;
               enemy.y = row * SIZE;
                break;
            case 4:
                Grass grassSpawn = new Grass();
                grassTiles.Add(grassSpawn);
                grassSpawn.x = col * SIZE;
                grassSpawn.y = row * SIZE;
                AddChild(grassSpawn);
                break;
        }
    }

    void waveLength()
    {
       
    }
    void waveUpdate()
    {
        if (Input.GetMouseButtonDown(0))
        {
            nextWaveActivate = true;
            nextWave_ = nextWave_ + 1;
        }
        if (nextWaveActivate && delay >= 0.1f)
        {
            delay -= delayDecrease;
            nextWaveActivate = false;
        }
    }

    void Update()
    {
        Timer();
        waveUpdate();
    }
   
    public int getWave()
    {
        return nextWave_;
    }
}

