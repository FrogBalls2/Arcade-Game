﻿using System;
using GXPEngine;


public class Square : Sprite { 
    public Square() : base("square.png") 
    { 

    } 
} //case 1

