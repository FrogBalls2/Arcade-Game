﻿using System;
using GXPEngine;


public class Grass5 : Sprite
{
    public Grass5() : base("OG_Ground5.png")
    {

    }
} 

