﻿using System;
using GXPEngine;


public class Grass3 : Sprite
{
    public Grass3() : base("OG_Ground3.png")
    {

    }
} 

