﻿using System;
using GXPEngine;


public class Grass11 : Sprite
{
    public Grass11() : base("OG_Ground11.png")
    {

    }
} 

