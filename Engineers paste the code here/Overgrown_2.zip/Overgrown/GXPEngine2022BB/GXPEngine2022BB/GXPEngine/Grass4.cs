﻿using System;
using GXPEngine;


public class Grass4 : Sprite
{
    public Grass4() : base("OG_Ground4.png")
    {

    }
} 

