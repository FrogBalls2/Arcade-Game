﻿using System;
using GXPEngine;

public class SlownessTile : Sprite
{


    public SlownessTile() : base("square.png")
    {

    }
}

    
   