﻿using System;
using GXPEngine;


public class Grass12 : Sprite
{
    public Grass12() : base("OG_Ground12.png")
    {

    }
} 

