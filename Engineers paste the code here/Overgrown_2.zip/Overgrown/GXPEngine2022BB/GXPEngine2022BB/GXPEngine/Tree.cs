﻿using System;
using GXPEngine;


public class Tree : Sprite
{
    public Tree() : base("Overgrown_Tree.png")
    {

    }

   


} //case 1

