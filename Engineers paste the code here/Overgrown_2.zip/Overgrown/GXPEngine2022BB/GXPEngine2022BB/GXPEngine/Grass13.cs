﻿using System;
using GXPEngine;


public class Grass13 : Sprite
{
    public Grass13() : base("OG_Ground13.png")
    {

    }
} 

