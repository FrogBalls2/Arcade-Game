﻿using System;
using GXPEngine;


public class Grass6 : Sprite
{
    public Grass6() : base("OG_Ground6.png")
    {

    }
} 

