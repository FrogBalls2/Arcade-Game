﻿using System;
using GXPEngine;


public class Grass14 : Sprite
{
    public Grass14() : base("OG_Ground14.png")
    {

    }
} 

