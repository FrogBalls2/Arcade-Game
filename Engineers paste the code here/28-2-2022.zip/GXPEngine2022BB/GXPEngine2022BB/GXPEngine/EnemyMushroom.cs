﻿using System;
using GXPEngine;

public class EnemyMushroom : AnimationSprite
{
    float speedX;
    float speedY;
    int healthEnemyMushroom;
    float animationSpeed = 0.05f;
    UserInterface _userInterface;
    Level _level;
    
    public EnemyMushroom() : base("Mushroom.png", 5, 1)
    {
        SetOrigin(width/2,height/2);
        speedX = 1.0f;
        speedY = 1.0f;
        healthEnemyMushroom = 1;

        _userInterface = game.FindObjectOfType<UserInterface>();
        _level = game.FindObjectOfType<Level>();
    }

    void health()
    {
        if (healthEnemyMushroom <= 0)
            {
            EnemyMushroomGone();
            }
    }

    public void EnemyMushroomGone()
    {
        _userInterface.score += 20;
        _level.enemies2.Remove(this);
        this.LateDestroy();  
    }
    void Update()
    {
        EnemyMushroomAnimator();
        FindPlayer();
    }

    void EnemyMushroomAnimator()
    {
        SetCycle(0, 5);
        Animate(animationSpeed);
    }


    void FindPlayer()
    {
        x = x + speedX;
        y = y + speedY;
        speedX = speedX * 0.9f;
        speedY = speedY * 0.9f;
    }
}