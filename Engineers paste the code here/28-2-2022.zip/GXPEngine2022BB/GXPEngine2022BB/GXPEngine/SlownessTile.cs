﻿using System;
using GXPEngine;

public class SlownessTile : Sprite
{


    public SlownessTile() : base("flower_tile.png")
    {

    }
}

    
   