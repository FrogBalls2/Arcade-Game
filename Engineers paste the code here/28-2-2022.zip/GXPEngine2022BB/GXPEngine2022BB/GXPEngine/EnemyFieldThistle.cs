﻿using System;
using GXPEngine;

public class EnemyFieldThistle : AnimationSprite
{
    float speedX;
    float speedY;
    int healthEnemyFieldThistle;
    float animationSpeed = 0.05f;
    UserInterface _userInterface;
    Level _level;
    
    public EnemyFieldThistle() : base("field_thistle_sprite_sheet.png", 5, 1)
    {
        SetOrigin(width/2,height/2);
        speedX = 1.0f;
        speedY = 1.0f;
        healthEnemyFieldThistle = 1;

        _userInterface = game.FindObjectOfType<UserInterface>();
        _level = game.FindObjectOfType<Level>();
    }

    void health()
    {
        if (healthEnemyFieldThistle <= 0)
            {
            EnemyFieldThistleGone();
            }
    }

    public void EnemyFieldThistleGone()
    {
        _userInterface.score += 25;
        _level.enemies3.Remove(this);
        this.LateDestroy();
        
    }
    void Update()
    {
        EnemyFieldThistleAnimator();
        FindPlayer();
    }

    void EnemyFieldThistleAnimator()
    {
        SetCycle(0, 5);
        Animate(animationSpeed);
    }


    void FindPlayer()
    {
        x = x + speedX;
        y = y + speedY;
        speedX = speedX * 0.9f;
        speedY = speedY * 0.9f;
    }
}