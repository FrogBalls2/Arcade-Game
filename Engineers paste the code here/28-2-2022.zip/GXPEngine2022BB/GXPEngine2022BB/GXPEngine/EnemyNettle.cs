﻿using System;
using GXPEngine;

public class EnemyNettle : AnimationSprite
{
    float speedX;
    float speedY;
    int healthEnemyNettle;
    float animationSpeed = 0.05f;
    UserInterface _userInterface;
    Level _level;
    
    public EnemyNettle() : base("nettle_sprite_sheet.png", 6, 1)
    {
        SetOrigin(width/2,height/2);
        speedX = 1.0f;
        speedY = 1.0f;
        healthEnemyNettle = 1;

        _userInterface = game.FindObjectOfType<UserInterface>();
        _level = game.FindObjectOfType<Level>();
    }

    void health()
    {
        if (healthEnemyNettle <= 0)
            {
            EnemyNettleGone();
            }
    }

    public void EnemyNettleGone()
    {
        _userInterface.score += 15;
        _level.enemies4.Remove(this);
        this.LateDestroy();
        
    }
    void Update()
    {
        EnemyNettleAnimator();
        FindPlayer();
    }

    void EnemyNettleAnimator()
    {
        SetCycle(0, 6);
        Animate(animationSpeed);
    }


    void FindPlayer()
    {
        x = x + speedX;
        y = y + speedY;
        speedX = speedX * 0.9f;
        speedY = speedY * 0.9f;
    }
}