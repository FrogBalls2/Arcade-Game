﻿using System;
using GXPEngine;


public class Grass15 : Sprite
{
    public Grass15() : base("OG_Ground15.png")
    {

    }
} 

