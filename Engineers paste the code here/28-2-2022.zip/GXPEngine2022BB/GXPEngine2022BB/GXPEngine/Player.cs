﻿using GXPEngine;
using System;
using GXPEngine.Core;

public class Player : AnimationSprite
{
    float speedX;
    float speedY;
    float playerSpeed = 0.15f;
    int _score;
    public int health;
    float sizeChar = 0.7f;
    float animationSpeed = 0.05f;
    float currentTime;
    bool isSlowed = false;
    float slownessTime = 1.0f;
    float slownessTimeSave;

    Sound deathSound;
    Sound hitSound;

    UserInterface _userInterface;

    public Player() : base("Character_Prototype_Spritesheet.png", 16, 1)
    {
        SetOrigin(width/2, height/2);
        scale = 3;
        speedX = 0.0f;
        speedY = 0.0f;
        health = 3;
        PlayerSpawn();
        deathSound = new Sound("Dying1.wav", false, false);
        hitSound = new Sound("Dying2.wav", false, false);
    }

    void Update()
    {   
        if (_userInterface == null)
        {
            _userInterface = parent.FindObjectOfType<UserInterface>();
        }
        Movement();
        IsPlayerAlive();
        SlownessTimer();
    }

    void SlownessTimer()
    {
        if (_userInterface != null)
        {
            currentTime = _userInterface.getTime();
        }

        if (isSlowed)
        {
            playerSpeed = 0.05f;
            if (currentTime - slownessTimeSave >= slownessTime)
            {
                playerSpeed = 0.15f;
                isSlowed = false;
            }
        }
    }

    public int GetScore() 
    { 
        return _score;
    }

    void PlayerSpawn()
    {
        x = game.width/2;
        y = game.height/2;
        health = 3;
        scale = sizeChar;
    }

     void Movement()
    {
        
        
        if(Input.GetKey(Key.W))
        {
            speedY = speedY - playerSpeed;
            SetCycle(4,2);
           
            
        }
        if (Input.GetKey(Key.S))
        {
            speedY = speedY + playerSpeed;
            SetCycle(2, 2);
        }
        if (Input.GetKey(Key.A))
        {
            speedX = speedX - playerSpeed;
           
            SetCycle(11, 5);

        }
        if (Input.GetKey(Key.D))
        {
            speedX = speedX + playerSpeed;
            
            SetCycle(6, 5);
        }
        if (!Input.GetKey(Key.D) && !Input.GetKey(Key.W) && !Input.GetKey(Key.A) && !Input.GetKey(Key.S)) { SetCycle(0, 2); }
        x = x + speedX;
        y = y + speedY;
        speedX = speedX * 0.9f;
        speedY = speedY * 0.9f;

        Animate(animationSpeed);
        
    }

    void IsPlayerAlive()
    {
        if(health <1)
        {
            deathSound.Play();
            PlayerSpawn();
            Console.WriteLine("dead");
        } 
    }

    void OnCollision(GameObject other)
    {
        if(other is EnemyVenusFlytrap)
        {
            EnemyVenusFlytrap enemyVenusFlytrap = (EnemyVenusFlytrap)other;
            speedX = 0.0f;
            speedY = 0.0f;
            if (health > 1)
            {
                hitSound.Play();
            }
            health--;
            _userInterface.health = health;
           
            
            enemyVenusFlytrap.EnemyVenusFlytrapGone();
        }
        if (other is EnemySpineCaterPillar)
        {
            EnemySpineCaterPillar enemySpineCaterPillar = (EnemySpineCaterPillar)other;
            speedX = 0.0f;
            speedY = 0.0f;
            if (health > 1)
            {
                hitSound.Play();
            }
            health--;
            _userInterface.health = health;
            

            enemySpineCaterPillar.EnemySpineCaterPillarGone();
        }
        if (other is EnemyMushroom)
        {
            EnemyMushroom enemyMushroom = (EnemyMushroom)other;
            speedX = 0.0f;
            speedY = 0.0f;
            if (health > 1)
            {
                hitSound.Play();
            }
            health--;
            _userInterface.health = health;
            

            enemyMushroom.EnemyMushroomGone();
        }
        if (other is EnemyFieldThistle)
        {
            EnemyFieldThistle enemyFieldThistle = (EnemyFieldThistle)other;
            speedX = 0.0f;
            speedY = 0.0f;
            if (health > 1)
            {
                hitSound.Play();
            }
            health--;
            _userInterface.health = health;
            

            enemyFieldThistle.EnemyFieldThistleGone();
        }
        if (other is EnemyNettle)
        {
            EnemyNettle enemyNettle = (EnemyNettle)other;
            speedX = 0.0f;
            speedY = 0.0f;
            if (health > 1)
            {
                hitSound.Play();
            }
            health--;
            _userInterface.health = health;
            

            enemyNettle.EnemyNettleGone();
        }
        if (other is SlownessTile)
        {
            isSlowed = true;
            slownessTimeSave = currentTime;
        }
    }

}


















