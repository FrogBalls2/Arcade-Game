﻿using System;
using GXPEngine;

public class EnemySpineCaterPillar : AnimationSprite
{
    float speedX;
    float speedY;
    int healthSpineCaterPillar;
    float animationSpeed = 0.05f;

    UserInterface _userInterface;
    Level _level;
    
    public EnemySpineCaterPillar() : base("SpineCaterPillar.png", 4, 1)
    {
        SetOrigin(width/2,height/2);
        speedX = 1.0f;
        speedY = 1.0f;
        healthSpineCaterPillar = 1;

        _userInterface = game.FindObjectOfType<UserInterface>();
        _level = game.FindObjectOfType<Level>();
    }

    void health()
    {
        if (healthSpineCaterPillar <= 0)
        {
            EnemySpineCaterPillarGone();
        }
    }

    public void EnemySpineCaterPillarGone()
    {
        
        
        _userInterface.score += 15;
        _level.enemies1.Remove(this);
        this.LateDestroy();

    }
    void Update()
    {
        EnemySpineCaterPillarAnimator();
        FindPlayer();
    }

    void EnemySpineCaterPillarAnimator()
    {
        SetCycle(0, 4);
        Animate(animationSpeed);
    }


    void FindPlayer()
    {
        x = x + speedX;
        y = y + speedY;
        speedX = speedX * 0.9f;
        speedY = speedY * 0.9f;
    }
}