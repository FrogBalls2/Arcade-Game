﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using GXPEngine;

namespace GXPEngine
{
    class EndScreen : EasyDraw
    {
        static int screenX = 1280;
        static int screenY = 720;
        public int score = 0;
        public EndScreen() : base (screenX, screenY)
        {

        }
        void Update()
        {
            QuitGame();
            RestartGame();
            Text();
        }

        void Text()
        {
            graphics.Clear(Color.Empty);

            Fill(Color.SeaGreen);
            Rect(screenX / 2, 425, 250, 75);
            Fill(Color.IndianRed);
            Rect(screenX / 2, 525, 250, 75);

            Fill(Color.White);
            TextAlign(CenterMode.Center, CenterMode.Center);
            TextFont("Verdana", 40f, FontStyle.Bold);

            Text("Restart", screenX / 2, 425);
            Text("Quit", screenX / 2, 525);

            TextFont("Verdana", 35f, FontStyle.Italic);
            Text("Final score: " + score, screenX / 2, 225);

            TextFont("Verdana", 60f, FontStyle.Bold);
            Fill(Color.IndianRed);
            Text("Game over", screenX / 2, 125);
        }

        void RestartGame()
        {
            if (Input.GetMouseButtonDown(0))
            {
                if (Input.mouseX > screenX / 2 - 125 && Input.mouseX < screenX / 2 + 125)
                {
                    if (Input.mouseY > 425 - 35.5 && Input.mouseY < 425 + 35.5)
                    {
                        this.LateDestroy();
                        game.FindObjectOfType<MyGame>().gameStarted = true;
                        game.FindObjectOfType<MyGame>().gameStartRanOnce = false;
                    }
                }

            }
        }
        void QuitGame()
        {
            if (Input.GetMouseButtonDown(0))
            {
                if (Input.mouseX > screenX / 2 - 125 && Input.mouseX < screenX / 2 + 125)
                {
                    if (Input.mouseY > 525 - 35.5 && Input.mouseY < 525 + 35.5)
                    {
                        game.Destroy();
                    }
                }

            }
        }
    }
}
