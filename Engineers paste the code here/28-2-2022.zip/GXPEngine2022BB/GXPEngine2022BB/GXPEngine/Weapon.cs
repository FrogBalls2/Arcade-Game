﻿using System;
using GXPEngine;


public class Weapon : Sprite
{
    Player _player;
    UserInterface _userInterface;
    int lastButtonPressed = 4; //1 is w, 2 is a, 3 is s, 4 is d
    bool isReturning = false;
    Sound hitSound;

    // time variables
    float currentTime; // Holds current time 
    float delay = 2f; // Delay of holding button
    float buttonPressTime; // Time when button is pressed
    float speedX = 5f;
    float speedY = 5f;


    public Weapon () : base("Scythe.png")
    {
        visible = false;
        SetOrigin(width / 2, height / 2);
        scale = 0f;
        hitSound = new Sound("Hit.wav", false, false);
        
    }
    void Update()
    {
        if(_player == null)
        {
            _player = parent.FindObjectOfType<Player>();
        }
        if(_userInterface == null)
        {
            _userInterface = parent.FindObjectOfType<UserInterface>();
        }
        ScytheDirection();
        ScytheAttack();
        Timer();
    }

    void Timer()
    {
        currentTime = _userInterface.getTime();
        if (Input.GetKeyDown(Key.E))
        {
            buttonPressTime = currentTime; // Keeps track of when you pressed the button
        }
        if (Input.GetKeyUp(Key.E))
        {
            if (currentTime - buttonPressTime > delay) // If button is held longer than 2 seconds
            {
                _userInterface.WeaponAttack(_player.x, _player.y, true);
            }
            else
            {
                _userInterface.WeaponAttack(_player.x, _player.y, false);
            }
        }

    }

    void ScytheDirection()
    {
        if (Input.GetKeyDown(Key.W))
        {
            lastButtonPressed = 1;
        }
        if (Input.GetKeyDown(Key.A))
        {
            lastButtonPressed = 2;
        }
        if (Input.GetKeyDown(Key.S))
        {
            lastButtonPressed = 3;
        }
        if (Input.GetKeyDown(Key.D))
        {
            lastButtonPressed = 4;
        }
    }

    void ScytheAttack()
    {
        if (Input.GetKeyDown(Key.E) && !visible)
        {
            visible = true;

            switch (lastButtonPressed)
            {
                case 1:
                    speedY = -3.5f;
                    speedX = 0f;
                    break;
                case 2:
                    speedX = -3.5f;
                    speedY = 0f;
                    break;
                case 3:
                    speedY = 3.5f;
                    speedX = 0f;
                    break;
                case 4:
                    speedX = 3.5f;
                    speedY = 0f;
                    break;
            }
        }

        if (visible)
        {
            scale = 0.6f;
            rotation += 0.8f * Time.deltaTime;

            if (!isReturning)
            {
                if (speedX != 0f)
                {
                    if (speedX >= 0f)
                    {
                        speedX -= 0.005f * Time.deltaTime;
                    }
                    else
                    {
                        speedX += 0.005f * Time.deltaTime;
                    }
                }

                if (speedY != 0f)
                {
                    if (speedY >= 0f)
                    {
                        speedY -= 0.005f * Time.deltaTime;
                    }
                    else
                    {
                        speedY += 0.005f * Time.deltaTime;
                    }
                }

                if (speedX >= -0.2f && speedX <= 0.2f && speedY >= -0.2f && speedY <= 0.2f)
                {
                    isReturning = true;
                }
            }
            // If scythe is returning to player
            else
            {
                if (x > _player.x)
                {
                    speedX = -3f;
                }
                else
                {
                    speedX = 3f;
                }

                if (y > _player.y)
                {
                    speedY = -3f;
                }
                else
                {
                    speedY = 3f;
                }

                if (x >= _player.x - 2f && x <= _player.x + 2f && y >= _player.y - 2f && y <= _player.y + 2f)
                {
                    visible = false;
                    isReturning = false;
                }
            }

            x += speedX;
            y += speedY;
        }
        // If scythe is invisible
        else
        {
            scale = 0f;
            x = _player.x;
            y = _player.y;
        }  
    }
    void OnCollision(GameObject other)
    {
        if (other is EnemyVenusFlytrap)
        {
            EnemyVenusFlytrap enemyVenusFlytrap = (EnemyVenusFlytrap)other;
            speedX = 0.0f;
            speedY = 0.0f;
            
            hitSound.Play(volume: 0.25f);
            enemyVenusFlytrap.EnemyVenusFlytrapGone();
        }
        if (other is EnemySpineCaterPillar)
        {
            EnemySpineCaterPillar enemySpineCaterPillar = (EnemySpineCaterPillar)other;
            speedX = 0.0f;
            speedY = 0.0f;
            hitSound.Play(volume: 0.25f);
            enemySpineCaterPillar.EnemySpineCaterPillarGone();
        }
        if (other is EnemyMushroom)
        {
            EnemyMushroom enemyMushroom = (EnemyMushroom)other;
            speedX = 0.0f;
            speedY = 0.0f;
            hitSound.Play(volume: 0.25f);
            enemyMushroom.EnemyMushroomGone();
        }
        if (other is EnemyFieldThistle)
        {
            EnemyFieldThistle enemyFieldThistle = (EnemyFieldThistle)other;
            speedX = 0.0f;
            speedY = 0.0f;
            hitSound.Play(volume: 0.25f);
            enemyFieldThistle.EnemyFieldThistleGone();
        }
        if (other is EnemyNettle)
        {
            EnemyNettle enemyNettle = (EnemyNettle)other;
            speedX = 0.0f;
            speedY = 0.0f;
            hitSound.Play(volume: 0.25f);
            enemyNettle.EnemyNettleGone();
        }
    }
}
