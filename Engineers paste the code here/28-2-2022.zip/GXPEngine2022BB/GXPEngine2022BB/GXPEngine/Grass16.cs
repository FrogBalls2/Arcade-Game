﻿using System;
using GXPEngine;


public class Grass16 : Sprite
{
    public Grass16() : base("OG_Ground16.png")
    {

    }
} 

