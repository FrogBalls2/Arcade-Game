﻿using System;
using GXPEngine;


public class Grass9 : Sprite
{
    public Grass9() : base("OG_Ground9.png")
    {

    }
} 

