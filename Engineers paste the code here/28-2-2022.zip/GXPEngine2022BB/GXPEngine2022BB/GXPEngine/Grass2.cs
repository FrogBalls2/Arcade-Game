﻿using System;
using GXPEngine;


public class Grass2 : Sprite
{
    public Grass2() : base("OG_Ground2.png")
    {

    }
} 

