﻿using System;
using GXPEngine;


public class Grass8 : Sprite
{
    public Grass8() : base("OG_Ground8.png")
    {

    }
} 

