﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using GXPEngine;

namespace GXPEngine
{
    public class UserInterface : EasyDraw
    { 
        static int screenX = 1280;
        static int screenY = 720;
        int offsetX = 720 / 2;
        int offsetY = 720 / 2;
        
        public int waveHeight = 1;

        private Level _level;

        float timeLevel = 30;
        float currentTime;

        float waveAddTime = 5;
        float waveDifference = 0;
        public int health = 3;

        float timer;

        public int score;

        // Vars for wave time
        float actualWaveTime;
        public float waveStartTime;
        int waveNumber = 1;
        int lastWaveNumber = 1;

        public UserInterface() : base(screenX, screenY)
        {
        }	

        void Text()
        {
            // Text
            
            graphics.Clear(Color.Empty);

            Fill(Color.White);
            TextSize(30f);
            TextAlign(CenterMode.Center, CenterMode.Center);
            TextFont("Verdana", 30f, FontStyle.Bold);

            Text("SCORE:", 1140, 125); // Text score letters
            Text(score + "", 1140, 175); // Text score numbers
            Text("WAVE: " + _level.getWave(), 140, 300); // Wave number

            // Hearts
            Fill(Color.Red);
            PlayerHead lives = new PlayerHead();
            lives.x = 1095;
            lives.y = 300;
            lives.scale = 1.5f;
            DrawSprite(lives);
            
            Text("x " + health, 1175, 300); 
        }
        void Timer()
        {
           if (_level.getWave() - waveDifference >= waveAddTime)
            {
                timeLevel += 10;
                waveDifference = _level.getWave();
            }

           if (timer >= 0)
            {
                timer = timeLevel - actualWaveTime;
                if (timer < 0)
                {
                    timer = 0;
                }

                Fill(Color.White);
                TextSize(30f);
                TextAlign(CenterMode.Center, CenterMode.Center);
                TextFont("Verdana", 20f, FontStyle.Bold);
                Text("Time: " + timer + " seconds", 150, 150);

            }
        }

        public void WeaponAttack(float playerX, float playerY, bool isCharged)
        {
            if (isCharged)
            {
                Fill(Color.Blue);
                Ellipse(playerX, playerY, 100, 100);
            }
            else
            {
                Fill(Color.Red);
                Ellipse(playerX, playerY, 100, 100);
            }
        }

        void Update()
        {
            // Sets time
            currentTime = Time.time / 1000;

            if (_level == null)
             {
                 _level = game.FindObjectOfType<Level>();
             }

            Text();
            Timer();
            SetActualWaveTime();
        }

        public float getTime()
        {
            return actualWaveTime;
        }

        public float getWaveTime()
        {
            return timer;
        }

        public void SetActualWaveTime()
        {
            actualWaveTime = currentTime - waveStartTime;
            waveNumber = _level.getWave();

            if(waveNumber > lastWaveNumber)
            {
                waveStartTime = currentTime;
                actualWaveTime = currentTime - waveStartTime;
                _level.spawnTime = actualWaveTime + _level.delay;
            }
            lastWaveNumber = waveNumber;
        }
    }
}
