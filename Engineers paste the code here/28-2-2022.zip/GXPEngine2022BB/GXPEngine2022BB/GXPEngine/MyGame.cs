using System;									
using GXPEngine;                                
using System.Drawing;							

public class MyGame : Game
{
	
	Sound music;
	Player player;
	Weapon weapon;
	Level level;
	UserInterface ui;

	public bool gameStarted = false;
	public bool gameStartRanOnce = false;


	public MyGame() : base(1280, 720, false)		
	{

		music = new Sound("slow-2021-10-19_Funny_Bit_www.FesliyanStudios.com_1.mp3", true, true);
		music.Play(volume: 0.5f);
		MainMenu mainMenu = new MainMenu();
		AddChild(mainMenu);
	}

	// For every game object, Update is called every frame, by the engine:
	void Update()
	{
		
		

		if (gameStarted && !gameStartRanOnce)
		{
			// UI class
			
			ui = new UserInterface();
			AddChild(ui);
			
			level = new Level();
			AddChild(level);
			
			player = new Player();
			AddChild(player);
			
			weapon = new Weapon();
			AddChild(weapon);

			ui.waveStartTime = Time.time / 1000;
			gameStartRanOnce = true;
		}
		if (gameStarted && player.health < 1)
        {
			EndScreen endscreen = new EndScreen();
			AddChild(endscreen);
			endscreen.score = ui.score;
			player.LateDestroy();
			level.LateDestroy();
			weapon.LateDestroy();
			ui.LateDestroy();
		}
	}
	

	

	static void Main()							
	{
		new MyGame().Start();
	}
}