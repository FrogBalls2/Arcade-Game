﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using GXPEngine;

namespace GXPEngine
{
    class MainMenu : EasyDraw
    {
        static int screenX = 1280;
        static int screenY = 720;

        public MainMenu() : base(screenX, screenY)
        {

        }

        void Update()
        {
            QuitGame();
            StartGame();
            Text();
        }

        void Text()
        {
            graphics.Clear(Color.Empty);

            Fill(Color.SeaGreen);
            Rect(screenX / 2, 425, 250, 75);
            Fill(Color.IndianRed);
            Rect(screenX / 2, 525, 250, 75);

            Fill(Color.White);
            TextAlign(CenterMode.Center, CenterMode.Center);
            TextFont("Verdana", 40f, FontStyle.Bold);
            
            Text("Play", screenX / 2, 425);
            Text("Quit", screenX / 2, 525);


            Sprite title = new Sprite("Overgrownposter1.png");
            title.scale = 0.3f;
            title.x = screenX / 2;
            title.y = 125;
            DrawSprite(title);


            
        }

        void StartGame()
        {
            if (Input.GetMouseButtonDown(0))
            {
                if (Input.mouseX > screenX / 2 - 125 && Input.mouseX < screenX / 2 + 125)
                {
                    if (Input.mouseY > 425 - 35.5 && Input.mouseY < 425 + 35.5)
                    {
                        this.Destroy();
                        game.FindObjectOfType<MyGame>().gameStarted = true;
                    }
                }

            }
        }

        void QuitGame()
        {
            if(Input.GetMouseButtonDown(0))
            {
                if (Input.mouseX > screenX/2 - 125 && Input.mouseX < screenX/2 + 125)
                {
                    if (Input.mouseY > 525 - 35.5 && Input.mouseY < 525 + 35.5)
                    {
                        game.Destroy();
                    }
                }

            }
        }
    }
}
