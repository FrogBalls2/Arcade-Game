﻿using System;
using GXPEngine;


public class Grass10 : Sprite
{
    public Grass10() : base("OG_Ground10.png")
    {

    }
} 

