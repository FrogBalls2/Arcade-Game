﻿using System;
using GXPEngine;


public class Grass1 : Sprite
{
    public Grass1() : base("OG_Ground1.png")
    {

    }
} 

