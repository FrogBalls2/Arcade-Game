﻿using System;
using GXPEngine;


public class Grass7 : Sprite
{
    public Grass7() : base("OG_Ground7.png")
    {

    }
} 

