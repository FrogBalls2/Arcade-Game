﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using GXPEngine;

namespace GXPEngine
{
    public class UserInterface : EasyDraw
    { 
        static int screenX = 1280;
        static int screenY = 720;
        int offsetX = 720 / 2;
        int offsetY = 720 / 2;
        string spriteHearts = "reference to heart here";
        public int waveHeight = 1;

        private Level _level;

        float timeLevel = 30;
        float currentTime;

        float waveAddTime = 5;
        float waveDifference = 0;

        float timer;

        public UserInterface() : base(screenX, screenY)
        {
           
        }	

        

        void Text()
        {
            // Text
            
            graphics.Clear(Color.Empty);

            Fill(Color.White);
            TextSize(30f);
            TextAlign(CenterMode.Center, CenterMode.Center);
            TextFont("Verdana", 30f, FontStyle.Bold);

            Text("SCORE:", 1140, 125); // Text score letters
            Text("00000", 1140, 175); // Text score numbers
            Text("WAVE: " + _level.getWave(), 140, 300); // Wave number

            // Hearts
            Fill(Color.Red);
            Rect(1085, 300, 50, 50);
            Text("x 3", 1175, 300); 

            // Circles
            for (int i = 0; i < 7; i++)
            {
                if (i == 0 || i == 3 || i == 6)
                {
                    Fill(Color.LawnGreen);
                    Ellipse(140, 390 + (i * 40), 50, 50);
                }
                else
                {
                    Fill(Color.Beige);
                    Ellipse(140, 390 + (i * 40), 15, 15);
                }
            }
        }
        void Timer()
        {
           if (_level.getWave() - waveDifference >= waveAddTime)
            {
                Console.WriteLine("banaan");
                timeLevel += 10;
                waveDifference = _level.getWave();
            }

           if (timer >= 0)
            {
                timer = timeLevel - currentTime;
                if (timer < 0)
                {
                    timer = 0;
                }

                Fill(Color.White);
                TextSize(30f);
                TextAlign(CenterMode.Center, CenterMode.Center);
                TextFont("Verdana", 20f, FontStyle.Bold);
                Text("Time: " + timer + " seconds", 150, 150);

            }
        }

        public void WeaponAttack(float playerX, float playerY, bool isCharged)
        {
            if (isCharged)
            {
                Fill(Color.Blue);
                Ellipse(playerX, playerY, 100, 100);
            }
            else
            {
                Fill(Color.Red);
                Ellipse(playerX, playerY, 100, 100);
            }
            
        }

        void Update()
        {
            currentTime = Time.time / 1000;

            if (_level == null)
             {
                 _level = parent.FindObjectOfType<Level>();
             }

            Text();
            Timer();
            
        }
	}
}
