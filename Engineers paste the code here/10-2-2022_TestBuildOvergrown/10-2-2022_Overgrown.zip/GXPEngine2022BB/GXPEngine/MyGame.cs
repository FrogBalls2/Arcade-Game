using System;									
using GXPEngine;                                
using System.Drawing;							

public class MyGame : Game
{
	
	public MyGame() : base(1280, 720, false)		
	{
		// UI class
		UserInterface ui; 
		ui = new UserInterface();
		AddChild(ui);

		Level level;
		level = new Level();
		AddChild(level);

		Player player;
		player = new Player();
		AddChild(player);

		Weapon weapon;
		weapon = new Weapon();
		AddChild(weapon);
	}

	// For every game object, Update is called every frame, by the engine:
	void Update()
	{
		
	}

	static void Main()							
	{
		new MyGame().Start();
	}
}