﻿using System;
using GXPEngine;


public class Weapon : AnimationSprite
{
    Player _player;
    UserInterface _userInterface;

    // time variables
    float currentTime; // Holds current time 
    float delay = 2f; // Delay of holding button
    float buttonPressTime; // Time when button is pressed


    public Weapon () : base("Weapon.png",0,0)
    {
     
    }

    void Timer()
    {
        currentTime = Time.time / 1000f; // Sets time in seconds
        if (Input.GetKeyDown(Key.E))
        {
            buttonPressTime = currentTime; // Keeps track of when you pressed the button
        }
        if (Input.GetKeyUp(Key.E))
        {
            if (currentTime - buttonPressTime > delay) // If button is held longer than 2 seconds
            {
                _userInterface.WeaponAttack(_player.x, _player.y, true);
            }
            else
            {
                _userInterface.WeaponAttack(_player.x, _player.y, false);
            }
        }

    }

    void Update()
    {
        Timer();

        if (_player == null)
        {
            _player = parent.FindObjectOfType<Player>();
        }
        if (_userInterface == null)
        {
            _userInterface = parent.FindObjectOfType<UserInterface>();
        }
    }
}
