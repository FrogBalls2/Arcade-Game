﻿using GXPEngine;
using System;

public class Player : AnimationSprite
{
    float speedX;
    float speedY;
    int _score;
    int health;
    float sizeChar = 0.4f;
    

    public Player() : base("Character_Prototype_Spritesheet.png", 16, 1)
    {
        SetOrigin(width/2, height/2);
        scale = 3;
        speedX = 0.0f;
        speedY = 0.0f;
        health = 3;
        PlayerSpawn();
    }

    public void Update()
    {
        Movement();
        IsPlayerAlive();
        Console.WriteLine(health);
       
    }
    public int GetScore() { return _score; }

    void PlayerSpawn()
    {
        x = game.width/2;
        y = game.height/2;
        health = 3;
        scale = sizeChar;

    }

     void Movement()
    {
        
        
        if(Input.GetKey(Key.W))
        {
            speedY = speedY - 0.3f;
            SetCycle(4,2);
           
            
        }
        else if (Input.GetKey(Key.S))
        {
            speedY = speedY + 0.3f;
            SetCycle(2, 2);
        }
        else if (Input.GetKey(Key.A))
        {
            speedX = speedX - 0.3f;
           
            SetCycle(11, 5);

        }
        else if (Input.GetKey(Key.D))
        {
            speedX = speedX + 0.3f;
            
            SetCycle(6, 5);
        }
        else { SetCycle(0, 2); }
        x = x + speedX;
        y = y + speedY;
        speedX = speedX * 0.9f;
        speedY = speedY * 0.9f;


        Animate(0.02f);

       
    }

    void IsPlayerAlive()
    {
        if(health <1)
        {
            
            PlayerSpawn();
            Console.WriteLine("dead");
        } 
    }

   



    void OnCollision(GameObject other)
    {
        if(other is Enemy)
        {
            Enemy enemy = (Enemy)other;
            speedX = 0.0f;
            speedY = 0.0f;
            health=health-1;
            enemy.EnemyGone();

        }
    }

}


















