﻿using GXPEngine;
using System.Collections.Generic;
using System;

public class Level : GameObject
{
    UserInterface ui;

    List<Grass> grassTiles;

    //timer
    float spawnTime;
    float delay = 2;
    float currentTime;

    int nextWave_ = 1;

    Random rnd = new Random();
    
    const int WIDTH = 23;
    const int HEIGHT = 40;
    const int SIZE = 32;

    void Timer()
    {
        currentTime = Time.time / 1000;
        
        if (currentTime >= spawnTime)
        {
            int randomNumber = rnd.Next(0, grassTiles.Count);
            Grass selectedTile = grassTiles[randomNumber];
            Enemy enemy = new Enemy();
            enemy.x = selectedTile.x;
            enemy.y = selectedTile.y;
            AddChild(enemy);



            spawnTime = currentTime + delay;
        }
    }


    int[,] level = new int[WIDTH, HEIGHT]
    {
     {0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0,0,0,0,0,0 },
     {0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0 },

    };

    public Level()
    {
        ui = FindObjectOfType<UserInterface>();
        grassTiles = new List<Grass>();
        // Player player = new Player();
        //AddChild(player);
        //HUD hud = new HUD(player);
        // AddChild(hud);

        for (int row = 0; row < WIDTH; row++)
        {
            for (int col = 0; col < HEIGHT; col++)
            {
                int tile = level[row, col];
                createTile(row, col, tile);
            }
        }
    }

    void createTile(int row, int col, int tile)
    {
        switch (tile)
        {
            case 1:
                Tree tree = new Tree();
                AddChild(tree);
                tree.x = col * SIZE;
                tree.y = row * SIZE;
                break;

            case 2:
                Grass grass = new Grass();
                grassTiles.Add(grass);
                AddChild(grass);
                grass.x = col * SIZE;
                grass.y = row * SIZE;
                break;

            case 3:
               Enemy enemy = new Enemy();
               AddChild(enemy);
               enemy.x = col * SIZE;
               enemy.y = row * SIZE;
                break;
        }
    }

    void waveLength()
    {
       
    }
    void Update()
    {
        Timer();
        
        if (Input.GetMouseButtonDown(0))
        {
            nextWave_ = nextWave_ + 1;
        }
    }
   
    public int getWave()
    {
        return nextWave_;
    }
}

